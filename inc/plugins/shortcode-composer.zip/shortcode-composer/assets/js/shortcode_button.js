(function() {
    tinymce.PluginManager.add('musa_tc_button', function( editor, url ) {
        editor.addButton( 'musa_tc_button', {
            title: 'Shortcode Composer',
            type: 'menubutton',
            icon: 'wp_code',
            classes:'musa_shortcode' ,
            menu: [
                {
                    text: 'Featured Posts Slider',
                    onclick: function() {
                        editor.windowManager.open( {
                            title: 'Insert Feature Posts Slider Details',
                            body: [
                                {
                                    type: 'textbox',
                                    name: 'featured_cat_slug',
                                    label: 'Category Slug',
                                    value: 'uncategorized'
                                },
                                {
                                    type: 'listbox',
                                    name: 'featured_cat_limit',
                                    label: 'Posts Limit',
                                    'values': [
                                        {text: '2', value: '2'},
                                        {text: '3', value: '3'},
                                        {text: '4', value: '4'},
                                        {text: '5', value: '5'},
                                        {text: '6', value: '6'},
                                        {text: '7', value: '7'},
                                        {text: '8', value: '8'}
                                    ]
                                }],
                            onsubmit: function( e ) {
                                editor.insertContent( '[post_slider cat_name="'+ e.data.featured_cat_slug+'" slide_limit="'+ e.data.featured_cat_limit+'"]');
                            }
                        });
                    }
                },
                {
                    text: 'Category Posts',
                    onclick: function() {
                        editor.windowManager.open( {
                            title: 'Category Posts 1',
                            body: [
                                {
                                    type: 'textbox',
                                    name: 'cat_style_1_title',
                                    label: 'Section Title',
                                    value: 'Business'
                                },
                                {
                                    type: 'textbox',
                                    name: 'cat_style_1_slug',
                                    label: 'Category Slug',
                                    value : 'uncategorized'
                                },
                                {
                                    type: 'textbox',
                                    name: 'cat_style_1_limit',
                                    label: 'Posts Limit',
                                    value:'6'
                                }],
                            onsubmit: function( e ) {
                                editor.insertContent('[cat title="'+ e.data.cat_style_1_title+'" cat_name="'+ e.data.cat_style_1_slug+'" post_limit="'+ e.data.cat_style_1_limit+'"]');
                            }
                        });
                    }
                },
                {
                    text: 'Minimal Category Posts',
                    onclick: function() {
                        editor.windowManager.open( {
                            title: 'Category Posts 3',
                            body: [
                                {
                                    type: 'textbox',
                                    name: 'cat_style_3_title',
                                    label: 'Section Title',
                                    value: 'Business'
                                },
                                {
                                    type: 'textbox',
                                    name: 'cat_style_3_slug',
                                    label: 'Category Slug',
                                    value : 'uncategorized'
                                },
                                {
                                    type: 'textbox',
                                    name: 'cat_style_3_limit',
                                    label: 'Posts Limit',
                                    value:'6'
                                }],
                            onsubmit: function( e ) {
                                editor.insertContent('[cat_minimal title="'+ e.data.cat_style_3_title+'" cat_name="'+ e.data.cat_style_3_slug+'" post_limit="'+ e.data.cat_style_3_limit+'"]');
                            }
                        });
                    }
                },
                {
                    text: 'Minimal 2 Category Posts',
                    onclick: function() {
                        editor.windowManager.open( {
                            title: '2 Category Posts',
                            body: [
                                {
                                    type: 'textbox',
                                    name: 'cat_style_31_title',
                                    label: 'Section Title',
                                    value: 'Business'
                                },
                                {
                                    type: 'textbox',
                                    name: 'cat_style_31_slug',
                                    label: 'Category Slug',
                                    value : 'uncategorized'
                                },
                                {
                                    type: 'textbox',
                                    name: 'cat_style_32_title',
                                    label: 'Section Title',
                                    value: 'Business'
                                },
                                {
                                    type: 'textbox',
                                    name: 'cat_style_32_slug',
                                    label: 'Category Slug',
                                    value : 'uncategorized'
                                },
                                {
                                    type: 'textbox',
                                    name: 'cat_style_3_limit',
                                    label: 'Posts Limit',
                                    value:'6'
                                }],
                            onsubmit: function( e ) {
                                editor.insertContent('[cat_minimal_2 title_1="'+ e.data.cat_style_31_title+'" cat_name_1="'+ e.data.cat_style_31_slug+'" title_2="'+ e.data.cat_style_32_title+'" cat_name_2="'+ e.data.cat_style_32_slug+'" post_limit="'+ e.data.cat_style_3_limit+'"]');
                            }
                        });
                    }
                },
                {
                    text: 'Advertisement',
                    onclick: function() {
                        editor.windowManager.open( {
                            title: 'Insert Advertisement',
                            body: [
                                {
                                    type: 'textbox',
                                    name: 'adds_img',
                                    label: 'Advertisement Image',
                                    value: 'http://placehold.it/730x100'
                                },
                                {
                                    type: 'textbox',
                                    name: 'adds_url',
                                    label: 'Advertisement Link',
                                    value: '#'
                                }
                            ],
                            onsubmit: function( e ) {
                                editor.insertContent( '[adds img="'+ e.data.adds_img+'" url="'+ e.data.adds_url+'"]');
                            }
                        });
                    }
                },
                {
                    text: 'Advertisement 2',
                    onclick: function() {
                        editor.windowManager.open( {
                            title: 'Insert Advertisement 2',
                            body: [
                                {
                                    type: 'textbox',
                                    name: 'adds_1_img',
                                    label: 'Advertisement Image',
                                    value: 'http://placehold.it/730x100'
                                },
                                {
                                    type: 'textbox',
                                    name: 'adds_1_url',
                                    label: 'Advertisement Link',
                                    value: '#'
                                },
                                {
                                    type: 'textbox',
                                    name: 'adds_2_img',
                                    label: 'Advertisement Image',
                                    value: 'http://placehold.it/730x100'
                                },
                                {
                                    type: 'textbox',
                                    name: 'adds_2_url',
                                    label: 'Advertisement Link',
                                    value: '#'
                                }
                            ],
                            onsubmit: function( e ) {
                                editor.insertContent( '[adds_half img_1="'+ e.data.adds_1_img+'" url_1="'+ e.data.adds_1_url+'" img_2="'+ e.data.adds_2_img+'" url_2="'+ e.data.adds_2_url+'"]');
                            }
                        });
                    }
                }
            ]
        });
    });
})();