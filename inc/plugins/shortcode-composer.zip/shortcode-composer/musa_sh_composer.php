<?php

    add_action('admin_head', 'musa_add_slider_tc_button');

    function musa_add_slider_tc_button(){
        global $typenow;
        // check user permissions
        if (!current_user_can('edit_posts') && !current_user_can('edit_pages')){
            return;
        }

        // verify the post type
        if( ! in_array( $typenow, array( 'post', 'page' ) ) )
            return;

        // check if WYSIWYG is enabled
        if ( get_user_option('rich_editing') == 'true') {
            add_filter("mce_external_plugins", "musa_add_slider_tinymce_plugin");
            add_filter('mce_buttons', 'musa_register_tc_button');
        }

    }

    function musa_add_slider_tinymce_plugin(){
        $plugin_array['musa_tc_button'] = plugins_url( '/assets/js/shortcode_button.js', __FILE__ ); // CHANGE THE BUTTON SCRIPT HERE
        return $plugin_array;
    }

    function musa_register_tc_button($buttons){
        array_push($buttons, "musa_tc_button");
        return $buttons;
    }

    function musa_shortcode_style() {
        wp_enqueue_style('musa_shortcode_style', plugins_url('/assets/css/style.css', __FILE__));
    }

    add_action('admin_enqueue_scripts', 'musa_shortcode_style');

// Add Shortcode
function muri_postSlider( $atts ) {

    // Attributes
    extract( shortcode_atts(
            array(
                'cat_name' => 'slide',
                'slide_limit' => '4',
            ), $atts )
    );

    $output  = '<div class="featured-post">';
    $output .= '<div id="owl-featured-post" class="owl-carousel owl-theme">';
    $args = array( 'post_type' => 'post', 'category_name' => $cat_name ,'posts_per_page' =>$slide_limit, 'order' => 'DESC' );
    $loop = new WP_Query( $args );
    global $post;
    while ( $loop->have_posts() ) : $loop->the_post();
        if (has_post_thumbnail( $post->ID ) ) {
            $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'slide');
        }else{
            $image[0] = 'http://placehold.it/730x450';
        }
        $output .= '<div class="item">
                            <img src="'.$image[0].'" alt="'.get_the_title($post->ID).'" >
                            <div class="featured-post-text">
                                <a href="'.get_the_permalink($post->ID).'">
                                    <h3 class="text-center">'.get_the_title($post->ID).'</h3>
                                </a>
                                <a href="'.get_the_permalink($post->ID).'" class="btn btn-default btn-round-brd">'.__('LEARN MORE','muri').'</a>
                            </div>
                        </div>';
    endwhile;
    wp_reset_query();wp_reset_postdata();
    $output .= '</div>';
    $output .= '</div>';

    return $output;
}
add_shortcode( 'post_slider', 'muri_postSlider' );

function muri_CatPost($atts){
    extract( shortcode_atts(
            array(
                'title' => 'Business',
                'cat_name' => 'slide',
                'post_limit' => '4',
            ), $atts )
    );

    $output  = '<div class="cat-post-section">';
    $output .= '<h2 class="cat-title">'.esc_attr($title).'</h2>';
    $args = array( 'post_type' => 'post', 'category_name' => $cat_name ,'posts_per_page' =>$post_limit, 'order' => 'DESC' );
    $loop = new WP_Query( $args );
    global $post;
    while ( $loop->have_posts() ) : $loop->the_post();
        if (has_post_thumbnail( $post->ID ) ) {
            $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'slide');
        }else{
            $image[0] = 'http://placehold.it/210x210';
        }
        $cats = array();
        global $post;
        foreach(wp_get_post_categories($post->ID) as $c)
        {
            $cat = get_category($c);
            array_push($cats,$cat->name);
        }
        $post_categories = '';
        if(sizeOf($cats)>0)
        {
            $post_categories = sprintf(esc_html_x('%s','post category','muri'),'<a href="'.esc_url( get_category_link( $cat->term_id ) ) .'">'.implode(',',$cats).'</a>');
        }
        $output .= '<div class="row item">
                                <div class="col-xs-12 col-sm-12 col-md-4">
                                    <img class="img-responsive" src="'.$image[0].'" alt="'.get_the_title($post->ID).'"/>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-8">
                                    <h2 class="post-title">
                                        <a href="'.get_the_permalink($post->ID).'">
                                            '.get_the_title($post->ID).'
                                        </a>
                                    </h2>
                                    <div class="post-meta">
                                        <span class="author">
                                            <i class="fa fa-user"></i>
                                            <a href="'.esc_url(get_author_posts_url( get_the_author_meta( 'ID' ))).'">
                                                '.esc_html( get_the_author() ).'
                                            </a>
                                        </span>
                                        <span class="date">
                                            <i class="fa fa-calendar"></i>
                                            '.date_i18n( get_option( 'date_format' ), strtotime( '11/15-1976' ) ).'
                                        </span>
                                        <span class="in-cate">
                                            <i class="fa fa-pencil"></i>
                                            '.$post_categories.'
                                        </span>
                                    </div>
                                    <p class="post-desc">
                                        '.excerpt(20).'
                                    </p>
                                    <p>
                                        <a href="'.get_the_permalink($post->ID).'" class="btn btn-default btn-txt"><i class="fa fa-long-arrow-right"></i>'.__('LEARN MORE','muri').'</a>
                                    </p>
                                </div>
                            </div>';
    endwhile;
    wp_reset_query();wp_reset_postdata();

    $output .= '</div>';

    return $output;
}
add_shortcode('cat','muri_CatPost');

function muri_CatPost_minimal($atts){
    extract( shortcode_atts(
            array(
                'title' => 'Business',
                'cat_name' => 'slide',
                'post_limit' => '4',
            ), $atts )
    );

    $output  = '<div class="cat-post-section">';
    $output .= '<h2 class="cat-title-1">'.esc_attr($title).'</h2>';
    $args = array( 'post_type' => 'post', 'category_name' => $cat_name ,'posts_per_page' =>$post_limit, 'order' => 'DESC' );
    $loop = new WP_Query( $args );
    global $post;
    while ( $loop->have_posts() ) : $loop->the_post();
        if (has_post_thumbnail( $post->ID ) ) {
            $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'slide');
        }else{
            $image[0] = 'http://placehold.it/730x450';
        }
        $output .= '<div class="row item minimal">
                            <div class="col-xs-12 col-sm-12 col-md-2">
                                <img class="img-responsive" src="'.$image[0].'" alt="'.get_the_title($post->ID).'"/>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-10">
                                <h3 class="post-title">
                                        <a href="'.get_the_permalink($post->ID).'">
                                            '.get_the_title($post->ID).'
                                        </a>
                                    </h3>
                                <p class="post-desc">
                                    '.excerpt(20).'
                                </p>
                                <a href="'.get_the_permalink($post->ID).'" class="btn btn-default btn-txt-only"><i class="fa fa-long-arrow-right"></i>'.__('LEARN MORE','muri').'</a>

                            </div>
                        </div>';
    endwhile;
    wp_reset_query();wp_reset_postdata();

    $output .= '</div>';

    return $output;
}
add_shortcode('cat_minimal','muri_CatPost_minimal');

function muri_CatPost_minimal_with_2cat($atts){
    extract( shortcode_atts(
            array(
                'title_1' => 'Business',
                'title_2' => 'News',
                'cat_name_1' => 'slide',
                'cat_name_2' => 'slide',
                'post_limit' => '4',
            ), $atts )
    );
    $output  = '<div class="cat-post-section">';
    $output .= '<div class="row">';
    $output .= '<div class="col-xs-12 col-sm-12 col-md-6">';
    $output .= '<div class="cat-post-section_minimal">';
    $output .= '<h2 class="cat-title-1">'.$title_1.'</h2>';
    $args = array( 'post_type' => 'post', 'category_name' => $cat_name_1 ,'posts_per_page' =>$post_limit, 'order' => 'DESC' );
    $loop = new WP_Query( $args );
    global $post;
    while ( $loop->have_posts() ) : $loop->the_post();
        if (has_post_thumbnail( $post->ID ) ) {
            $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'slide');
        }else{
            $image[0] = 'http://placehold.it/730x450';
        }
        $output .= '<div class="row item minimal">
                                        <div class="col-xs-12 col-sm-12 col-md-4">
                                            <img class="img-responsive" src="'.$image[0].'" alt="'.get_the_title($post->ID).'"/>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-8">
                                            <h3 class="post-title">
                                                <a href="'.get_the_permalink($post->ID).'">
                                                    '.get_the_title($post->ID).'
                                                </a>
                                            </h3>
                                            <a href="'.get_the_permalink($post->ID).'" class="btn btn-default btn-txt-only"><i class="fa fa-long-arrow-right"></i>'.__('LEARN MORE','muri').'</a>

                                        </div>
                                    </div>';
    endwhile;
    wp_reset_query();wp_reset_postdata();
    $output .= '</div>';
    $output .= '</div>';
    $output .= '<div class="col-xs-12 col-sm-12 col-md-6">';
    $output .= '<div class="cat-post-section_minimal">';
    $output .= '<h2 class="cat-title-1">'.$title_2.'</h2>';
    $args = array( 'post_type' => 'post', 'category_name' => $cat_name_2 ,'posts_per_page' =>$post_limit, 'order' => 'DESC' );
    $loop = new WP_Query( $args );
    global $post;
    while ( $loop->have_posts() ) : $loop->the_post();
        if (has_post_thumbnail( $post->ID ) ) {
            $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'slide');
        }else{
            $image[0] = 'http://placehold.it/730x450';
        }
        $output .= '<div class="row item minimal">
                                            <div class="col-xs-12 col-sm-12 col-md-4">
                                                <img class="img-responsive" src="'.$image[0].'" alt="'.get_the_title($post->ID).'"/>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-8">
                                                <h3 class="post-title">
                                                    <a href="'.get_the_permalink($post->ID).'">
                                                        '.get_the_title($post->ID).'
                                                    </a>
                                                </h3>
                                                <a href="'.get_the_permalink($post->ID).'" class="btn btn-default btn-txt-only"><i class="fa fa-long-arrow-right"></i>'.__('LEARN MORE','muri').'</a>

                                            </div>
                                        </div>';
    endwhile;
    wp_reset_query();wp_reset_postdata();
    $output .= '</div>';
    $output .= '</div>';
    $output .= '</div>';
    $output .= '</div>';

    return $output;
}
add_shortcode('cat_minimal_2','muri_CatPost_minimal_with_2cat');

function muri_adds($atts){
    extract( shortcode_atts(
            array(
                'img' => 'http://placehold.it/730x120',
                'url' => '#',
            ), $atts )
    );
    $output = ' <div class="add-section">
                    <a href="'.esc_url($url).'">
                        <img src="'.esc_url($img).'" class="img-responsive" alt="Muri adds"/>
                    </a>
                </div>';

    return $output;
}
add_shortcode('adds','muri_adds');

function muri_adds_2($atts){
    extract( shortcode_atts(
            array(
                'img_1' => 'http://placehold.it/365x120',
                'url_1' => '#',
                'img_2' => 'http://placehold.it/365x120',
                'url_2' => '#',
            ), $atts )
    );
    $output = '<div class="add-section">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 p-r-0">
                                <a href="'.esc_url($url_1).'">
                                    <img src="'.esc_url($img_1).'" class="img-responsive" alt=""/>
                                </a>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 p-l-0">
                                <a href="'.esc_url($url_2).'">
                                    <img class="img-responsive" src="'.esc_url($img_2).'" alt=""/>
                                </a>
                            </div>
                        </div>
                    </div>';

    return $output;
}
add_shortcode('adds_half','muri_adds_2');
