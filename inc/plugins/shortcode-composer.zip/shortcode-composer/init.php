<?php
/*
Plugin Name: Shortcode Composer
Plugin URI: https://github.com/iammdmusa/shortcode-composer
Description: ...
Version: 0.1
Author: Md Musa
Author URI: https://github.com/iammdmusa
*/

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SM__PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SM__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );


// include WXR file parsers
require_once (SM__PLUGIN_DIR. 'musa_sh_composer.php');